var boton = document.getElementById("btnAgregar");

boton.onclick = function () {

    var comida = document.getElementById("listaComida").value;
    var estado = document.getElementById("listaEstado").value;
    var resultado = document.getElementById("resultado");

    resultado.innerHTML = "";

    if (comida == "" || estado == "") {
        resultado.innerHTML = "Debes seleccionar comida y estado";
        return;
    }

    if (estado == "planeacion") {
        resultado.innerHTML =
            "<div class='tarjeta colorPlaneacion'>" +
            comida + "<br>Ver videos de almuerzos</div>";
    } 
    else if (estado == "preparacion") {
        resultado.innerHTML =
            "<div class='tarjeta colorPreparacion'>" +
            comida + "<br>Agregar condimentos</div>";
    } 
    else {
        resultado.innerHTML =
            "<div class='tarjeta colorTerminado'>" +
            comida + "<br>No olvides lavarte las manos</div>";
    }
};
